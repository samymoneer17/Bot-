# 🚂 Quick Railway Deployment (5 minutes)

## 1️⃣ Get Your Telegram Token
Go to [@BotFather](https://t.me/botfather) on Telegram → `/newbot` → copy token

## 2️⃣ Create Railway Account
Visit [railway.app](https://railway.app) → Sign up with GitHub

## 3️⃣ Deploy (Choose ONE method)

### Method A: GitHub (Easiest - 2 minutes)
```bash
git add .
git commit -m "Ready for Railway"
git push origin main
```
Then:
1. Go to railway.app
2. Click **"New Project"** → **"Deploy from GitHub repo"**
3. Select this repo
4. Click **Deploy**
5. Wait 2-3 minutes

### Method B: Railway CLI
```bash
npm install -g @railway/cli
railway login
railway init
railway up
```

## 4️⃣ Add Environment Variables
In Railway dashboard:
- Click your project → **Variables** tab
- Add `BOT_TOKEN` = `your_token_here`
- Add `ADMIN_IDS` = `your_user_id` (find with `/start` command)

## 5️⃣ Done! ✅
Bot is now running on Railway! Send `/start` to your bot on Telegram to test.

---

## 📊 Deployment Files Created

✅ **Dockerfile** - Docker container config (python:3.11 + apktool + jdk)
✅ **Procfile** - Process file for Railway
✅ **railway.toml** - Railway configuration
✅ **requirements.txt** - All 40 Python dependencies
✅ **.gitignore** - Excludes temp files & secrets
✅ **DEPLOYMENT.md** - Full deployment guide
✅ **ARCHITECTURE.md** - System architecture docs

---

## 🔍 What's Inside

- **26 OSINT modules** for reconnaissance
- **APK analysis** with V1+V2+V3 signature detection
- **SSL pinning bypass** with automatic V1+V2+V3 signing
- **11,443 lines** of production code
- **Admin controls** for managing users

---

## 🚀 Features on Railway

✅ Auto-deploy on GitHub push (no downtime)
✅ Memory: 512MB (upgradeable)
✅ Monitoring & logs in dashboard
✅ $5/month free credit includes this bot
✅ No manual server management

---

## ⚠️ Important Notes

- **Never commit `.env` file** (it's in .gitignore)
- **Use Railway Variables** for sensitive data
- **temp/ auto-cleaned** on container restart
- **Logs accessible** in Railway dashboard
- **First deployment takes 3-5 minutes**

---

Done! Your bot is now production-ready. 🎉
