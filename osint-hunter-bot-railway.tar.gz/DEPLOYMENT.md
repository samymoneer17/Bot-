# 🚀 OSINT Hunter Bot - Railway Deployment Guide

## 📋 Prerequisites

1. **Telegram Bot Token** - Get from [@BotFather](https://t.me/botfather)
2. **Railway Account** - Sign up at [railway.app](https://railway.app)
3. **GitHub Account** (optional) - For auto-deployment

---

## 🛠️ Project Structure

```
osint-hunter-bot/
├── bot.py                 # Main bot handler
├── main.py               # Entry point
├── requirements.txt      # Python dependencies
├── Dockerfile            # Docker configuration
├── Procfile              # Process file
├── railway.toml          # Railway config (optional)
├── .env                  # Local environment (never commit)
├── .gitignore            # Git ignore rules
├── modules/              # Feature modules
│   ├── app_osint.py      # APK analysis (V1+V2+V3 signing)
│   ├── admin_panel.py    # Admin controls
│   ├── email_osint.py    # Email reconnaissance
│   ├── phone_osint.py    # Phone number lookup
│   └── ... (24 more modules)
└── temp/                 # Temporary files (auto-created)
```

---

## 🐳 Docker & Railway Setup

### Option 1: GitHub Auto-Deploy (Recommended)

1. **Push to GitHub:**
   ```bash
   git add .
   git commit -m "Prepare for Railway deployment"
   git push origin main
   ```

2. **Connect Railway to GitHub:**
   - Go to [railway.app](https://railway.app)
   - Click **"New Project"** → **"Deploy from GitHub repo"**
   - Select your repository
   - Railway auto-detects `Dockerfile` and builds

3. **Add Environment Variables:**
   - In Railway dashboard → Your Service → **Variables**
   - Add:
     - `BOT_TOKEN` = `your_telegram_bot_token`
     - `ADMIN_IDS` = `comma_separated_user_ids`

4. **Deploy:**
   - Railway auto-deploys on push
   - Watch deployment in **Deployments** tab

### Option 2: Railway CLI

```bash
# Install Railway CLI
npm install -g @railway/cli

# Login
railway login

# Link to your project
railway link

# Deploy
railway up

# Set environment variables
railway variables set BOT_TOKEN=your_token
railway variables set ADMIN_IDS=123456789
```

---

## 📦 Dependencies

The bot includes **11,443 lines of code** across 26 modules:

### Core Packages:
- `python-telegram-bot==22.5` - Telegram API
- `aiohttp==3.13.2` - Async HTTP requests
- `beautifulsoup4==4.14.3` - Web scraping
- `httpx==0.28.1` - Modern HTTP client
- `phonenumbers==9.0.20` - Phone analysis
- `holehe==1.61` - Email OSINT

### System Dependencies (in Dockerfile):
- `apktool` - APK analysis
- `aapt` - Android App Package Tool
- `default-jdk` - Java for signing
- `android-tools-adb` - ADB
- `jq` - JSON parsing

All dependencies are automatically installed from `requirements.txt`.

---

## 🔐 Security Notes

### ✅ Do's:
- Use Railway Variables for sensitive data (BOT_TOKEN, ADMIN_IDS)
- Never commit `.env` file to GitHub
- Use environment variables for all secrets

### ❌ Don'ts:
- Don't put tokens in code
- Don't commit `.env` to Git (it's in `.gitignore`)
- Don't expose admin IDs in public

---

## 🚨 Troubleshooting

### Bot not responding?
```bash
# Check logs in Railway
railway logs -f
```

### Memory issues?
- Railway default: 512MB
- Upgrade service in settings if needed
- APK processing can be memory-intensive

### Build fails?
- Check `Dockerfile` exists
- Verify `requirements.txt` is present
- Ensure all imports work: `python -m py_compile bot.py`

### APK processing fails?
- Verify `apktool` is installed (it's in Dockerfile)
- Check temp/ directory has write permissions
- For large APKs, may need upgraded Railway plan

---

## 📊 Features Deployed

### ✨ APK Analysis
- Full APK decompilation
- **APK Signature Detection (V1+V2+V3)**
- Certificate extraction
- Permission analysis
- Manifest analysis

### 🔓 SSL Pinning Bypass
- Automatic Network Security Config injection
- **Automatic V1+V2+V3 APK signing with apksigner**
- Fallback to jarsigner if needed

### 🔍 OSINT Modules (26 total)
- Email reconnaissance (Holehe)
- Phone number lookup
- Username search
- Social media OSINT
- IP geolocation
- DNS over HTTPS
- Web recon
- Cryptography analysis
- Deep web scanning (Shodan, Censys)
- And 16 more modules...

---

## 💡 Next Steps

1. **Customize bot.py:**
   - Add your custom handlers
   - Modify subscription logic
   - Adjust command permissions

2. **Monitor Usage:**
   - Railway dashboard shows CPU, memory, disk
   - Check logs regularly
   - Monitor bot activity

3. **Update Regularly:**
   - Push code changes to GitHub
   - Railway auto-deploys on push
   - No downtime needed

---

## 🔗 Useful Links

- [Railway Docs](https://docs.railway.app)
- [python-telegram-bot Docs](https://docs.python-telegram-bot.org)
- [APKTool Documentation](https://ibotpeaches.github.io/Apktool)
- [Telegram Bot API](https://core.telegram.org/bots/api)

---

## 📝 Environment Variables Reference

| Variable | Description | Example |
|----------|-------------|---------|
| `BOT_TOKEN` | Telegram bot token | `123456:ABC-DEF1234ghIkl-zyx57W2v1u123ew11` |
| `ADMIN_IDS` | Comma-separated admin user IDs | `123456789,987654321` |
| `PORT` | Port for webhook (if using) | `8080` |

---

✅ **Ready to deploy on Railway!**

For questions: Check Railway docs or Telegram bot API documentation.
