# 🏗️ OSINT Hunter Bot - Architecture

## 📐 System Overview

```
┌─────────────────────────────────────┐
│    Telegram Bot (python-telegram-bot)
│         bot.py / main.py             │
└─────────┬───────────────────────────┘
          │
    ┌─────┴──────────────────┐
    │                        │
    v                        v
┌──────────────┐    ┌──────────────────┐
│  26 OSINT    │    │  Admin Panel     │
│  Modules     │    │  + Controls      │
└──────────────┘    └──────────────────┘
```

## 📁 Directory Structure

### Core Files
- **bot.py** (3,843 lines) - Main bot logic, command handlers, callbacks
- **main.py** - Entry point that imports and runs bot
- **requirements.txt** - All Python dependencies

### Feature Modules (modules/)

#### App/APK Analysis
- **app_osint.py** - Advanced APK analyzer
  - V1 signature detection (JAR signing)
  - V2 signature detection (APK Signing Scheme v2)
  - V3 signature detection (APK Signing Scheme v3)
  - Certificate extraction & analysis
  - Permission analysis
  - Manifest parsing
  - SSL pinning bypass (Network Security Config)
  - Automatic V1+V2+V3 signing with `apksigner`

#### Email OSINT
- **email_osint.py** - Email reconnaissance
  - Holehe integration for email verification
  - Breach checking
  - Domain analysis

#### Phone OSINT
- **phone_osint.py** - Phone number analysis
  - Phone verification
  - WhatsApp OSINT
  - Reputation checking
  - Carrier & timezone info

#### Web & Network
- **web_recon.py** - Website reconnaissance
- **http_sec_osint.py** - HTTP security testing
- **doh_osint.py** - DNS over HTTPS
- **ip_geo_osint.py** - IP geolocation
- **url_tools.py** - URL analysis

#### Username & Social Media
- **username_osint.py** - Username search across sites
- **social_osint.py** - Facebook, Instagram, Twitter OSINT
- **reverse_image_osint.py** - Reverse image search

#### Advanced Tools
- **google_osint.py** - Google dorks & search
- **crypto_osint.py** - Cryptocurrency analysis
- **deep_web_osint.py** - Shodan, Censys, dark web
- **nmap_osint.py** - Network scanning
- **vuln_scanner.py** - Vulnerability scanning
- **sqlmap_osint.py** - SQL injection testing

#### Specialized Tools
- **national_id.py** - ID number analysis
- **security_tools.py** - Security checks (Cloudflare bypass)
- **download_tools.py** - File download utilities
- **argus_tools.py** - Additional OSINT
- **kraken_tools.py** - Web enumeration
- **lucille_tools.py** - Additional analysis

#### Admin & Control
- **admin_panel.py** - Admin commands & controls

## 🔄 Data Flow

### APK Processing Pipeline
```
APK Upload
    │
    ├─► Extract APK Info (size, name, package)
    │
    ├─► Full Decompilation (apktool)
    │
    ├─► Analysis:
    │   ├─ V1 Signature (JAR signing)
    │   ├─ V2 Signature (APK Signing Scheme v2)
    │   └─ V3 Signature (APK Signing Scheme v3)
    │
    ├─► Modifications (optional):
    │   ├─ Rename app
    │   ├─ Change icon
    │   ├─ Bypass SSL pinning
    │   └─ Add splash screen
    │
    ├─► Rebuild (apktool b)
    │
    ├─► Sign APK:
    │   ├─ Primary: apksigner (V1+V2+V3)
    │   └─ Fallback: jarsigner (V1)
    │
    └─► Send modified APK to user
```

### Command Flow
```
User Message
    │
    ├─► Check subscription/permissions
    ├─► Check user ban status
    ├─► Validate input
    ├─► Execute OSINT module
    └─► Send results
```

## 🛠️ Key Technologies

### Telegram
- **Library**: python-telegram-bot 22.5
- **Mode**: Long polling (no webhook)
- **Features**: Inline keyboards, callbacks, file uploads

### APK Tools
- **Decompilation**: apktool
- **Signing V1**: jarsigner (fallback)
- **Signing V1+V2+V3**: apksigner (primary)
- **Key Management**: keytool
- **APK Info**: aapt

### HTTP & Web
- **Async HTTP**: aiohttp, httpx
- **Web Scraping**: BeautifulSoup 4
- **Code Beautification**: cssbeautifier, jsbeautifier

### Data Analysis
- **Phone Parsing**: phonenumbers
- **Email OSINT**: holehe
- **Image Upload**: imgbbpy

## 🔐 Security Features

### APK Security
- V1, V2, V3 signature detection
- Certificate extraction & validation
- Permission analysis
- Manifest security checks
- SSL pinning bypass detection

### Bot Security
- Admin ID verification
- User ban list
- Subscription checks
- Rate limiting via subscription tiers
- Secure environment variables (Railway)

### OSINT Privacy
- No data storage (except temporary APK files)
- Auto-cleanup of temp files
- All processing in memory/temp
- No log files with sensitive data

## 📊 Performance

- **Bot Code**: 11,443 total lines
- **Modules**: 26 OSINT modules
- **Memory**: 512MB+ recommended (Railway)
- **Startup**: ~5 seconds
- **APK Processing**: 10-60 seconds (depends on size)

## 🚀 Deployment Architecture

```
GitHub Repository
    │
    └─► Railway Platform
        ├─► Docker Build (Dockerfile)
        ├─► Container Run
        └─► Telegram Bot Polling
```

### Docker Setup
- **Base Image**: python:3.11-slim
- **System Deps**: apktool, aapt, jdk, adb, jq
- **Python Deps**: requirements.txt
- **Entry Point**: python main.py

### Railway Specifics
- **Starter Tier**: $5/month free credit
- **Scaling**: Auto-scales with usage
- **Storage**: Ephemeral (temp/ cleared on restart)
- **Logging**: Railway dashboard
- **Env Vars**: BOT_TOKEN, ADMIN_IDS

## 🔄 Update Process

1. Make code changes locally
2. Test locally (if possible)
3. Commit to GitHub: `git push origin main`
4. Railway auto-deploys
5. No downtime during deployment
6. View logs in Railway dashboard

## 📝 Configuration

### Local Development
```bash
# Create .env file (not committed)
BOT_TOKEN=your_token
ADMIN_IDS=your_id

# Run bot
python main.py
```

### Production (Railway)
- Environment variables set in Railway dashboard
- Automatic via GitHub push
- Monitored in Railway logs

## 🎯 Next Steps

1. **Monitor Bot**: Check Railway dashboard regularly
2. **Add Custom Modules**: Extend modules/ directory
3. **Optimize Performance**: Profile APK processing
4. **Scale Infrastructure**: Upgrade Railway plan if needed

---

**Last Updated**: December 23, 2025
**Bot Version**: With V1+V2+V3 APK signing support
**Status**: Ready for production deployment
