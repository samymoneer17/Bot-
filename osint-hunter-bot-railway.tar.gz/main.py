
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
OSINT Hunter Bot V2.0
بوت تليجرام متقدم لجمع المعلومات
"""

from bot import main

if __name__ == "__main__":
    main()
