# 🤖 بوت OSINT Hunter - دليل سريع بالعربية

## 📦 الملف المضغوط: `osint-hunter-bot-railway.tar.gz` (104 كيلوبايت)

هذا الملف يحتوي على **كل شيء تحتاجه** لتشغيل البوت على Railway!

### ✅ محتويات الملف:
```
✓ bot.py (الكود الرئيسي)
✓ main.py (نقطة البداية)
✓ requirements.txt (المكاتب)
✓ Dockerfile (إعدادات Docker)
✓ Procfile (إعدادات Railway)
✓ railway.toml (ملف تكوين Railway)
✓ modules/ (26 مودول OSINT)
✓ DEPLOYMENT.md (دليل التثبيت الكامل)
✓ ARCHITECTURE.md (معمارية النظام)
✓ RAILWAY_SETUP.md (دليل سريع 5 دقائق)
```

---

## 🚀 خطوات التثبيت على Railway (5 دقائق فقط)

### الخطوة 1️⃣: احصل على توكن البوت
اذهب إلى [@BotFather](https://t.me/botfather) على Telegram
- أكتب `/newbot`
- اختر اسم البوت
- انسخ التوكن

### الخطوة 2️⃣: فك الملف المضغوط
```bash
tar -xzf osint-hunter-bot-railway.tar.gz
cd osint-hunter-bot-main
```

### الخطوة 3️⃣: ارفعه على GitHub
```bash
git init
git add .
git commit -m "OSINT Hunter Bot ready for Railway"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/osint-hunter-bot.git
git push -u origin main
```

### الخطوة 4️⃣: ثبته على Railway
1. اذهب إلى [railway.app](https://railway.app)
2. سجل الدخول بـ GitHub
3. اضغط **"New Project"**
4. اختر **"Deploy from GitHub repo"**
5. اختر مستودعك
6. اضغط **Deploy**
7. انتظر 2-3 دقائق

### الخطوة 5️⃣: أضف التوكن
في لوحة تحكم Railway:
- اذهب إلى **Variables**
- أضف: `BOT_TOKEN` = التوكن الذي نسخته
- أضف: `ADMIN_IDS` = معرف المستخدم الخاص بك

### الخطوة 6️⃣: تم! ✅
أرسل `/start` للبوت على Telegram - يجب أن يرد عليك!

---

## 🎯 ميزات البوت الرئيسية

### 📱 تحليل APK
```
✓ فك وتحليل ملفات APK
✓ كشف التوقيعات V1 + V2 + V3
✓ استخراج الشهادات
✓ تحليل الأذونات
✓ كسر SSL Pinning تلقائي
✓ إعادة التوقيع بـ V1+V2+V3
```

### 🔍 26 مودول OSINT
```
✓ البحث عن البريد الإلكتروني
✓ تتبع رقم الهاتف
✓ البحث عن أسماء المستخدمين
✓ معلومات وسائل التواصل الاجتماعي
✓ تحديد الموقع من IP
✓ فحص الويب والخوادم
✓ تحليل الأمان
✓ والمزيد...
```

---

## 📊 إحصائيات المشروع

| المقياس | الرقم |
|--------|-------|
| سطور الكود | 11,443 |
| ملفات الـ Python | 28 |
| مودولات OSINT | 26 |
| المكاتب المثبتة | 40 |
| حجم الملف المضغوط | 104 كيلوبايت |

---

## 🐳 معلومات Docker و Railway

### Docker يشمل على:
- Python 3.11
- apktool (لتحليل APK)
- aapt و JDK (لتوقيع APK)
- Android tools

### Railway يوفر:
- 512 ميجابايت ذاكرة عشوائية
- نشر تلقائي من GitHub
- لوحة تحكم للمراقبة
- $5 رصيد شهري مجاني

---

## ⚠️ نصائح مهمة

### ✅ افعل:
- استخدم Railway Variables للبيانات الحساسة (BOT_TOKEN)
- أرسل التغييرات إلى GitHub - Railway ينشرها تلقائياً
- افحص السجلات من لوحة تحكم Railway عند حدوث مشاكل

### ❌ لا تفعل:
- لا تضع التوكن في الكود مباشرة
- لا تحفظ ملف `.env` في GitHub
- لا تشارك معرف الإدارة علناً

---

## 🛠️ استكشاف الأخطاء

### البوت لا يرد؟
افحص السجلات في Railway Dashboard → Deployments → Logs

### خطأ في النشر؟
تأكد من وجود:
- Dockerfile
- requirements.txt
- main.py

### خطأ أثناء تحليل APK؟
تأكد من أن apktool مثبت (يتم في Dockerfile تلقائياً)

---

## 📚 ملفات التوثيق

في الملف المضغوط ستجد:
- **DEPLOYMENT.md** - دليل التثبيت الكامل
- **ARCHITECTURE.md** - معمارية وتصميم النظام
- **RAILWAY_SETUP.md** - دليل سريع 5 دقائق

---

## 🔗 روابط مهمة

- [Railway Documentation](https://docs.railway.app)
- [python-telegram-bot Docs](https://docs.python-telegram-bot.org)
- [Telegram Bot API](https://core.telegram.org/bots/api)
- [@BotFather](https://t.me/botfather) - إنشاء البوت

---

## ❓ أسئلة شائعة

**س: كم تكلفة Railway؟**
ج: $5 رصيد شهري مجاني يكفي لهذا البوت

**س: هل يعمل البوت 24/7؟**
ج: نعم! Railway يشغله طول الوقت

**س: كيف أحدّث البوت؟**
ج: قم بـ git push وRailway ينشره تلقائياً

**س: هل بيانات المستخدمين آمنة؟**
ج: البوت لا يحفظ أي بيانات - كل شيء في الذاكرة المؤقتة

---

## 📞 الدعم

إذا حدثت مشاكل:
1. افحص السجلات (Railway Logs)
2. تأكد من التوكن صحيح (@BotFather)
3. أعد تشغيل الخدمة في Railway
4. افحص ملفات DEPLOYMENT.md

---

**النسخة:** مع دعم V1+V2+V3 APK Signing
**التاريخ:** 23 ديسمبر 2025
**الحالة:** جاهز للإنتاج ✅

استمتع بـ OSINT Hunter Bot! 🚀
